import React, {
  useEffect,
  useState,
  useRef,
  useCallback,
  useMemo,
  forwardRef,
  useImperativeHandle,
} from 'react';
import {
  View,
  ActivityIndicator,
  StyleSheet,
  Alert,
  Linking,
  Platform,
  Dimensions,
  NativeModules,
} from 'react-native';
import { WebView } from 'react-native-webview';

const { FlixInpageModule } = NativeModules;

/* ============================================================================
 * SDK API
 * ========================================================================== */

export function initialize(username, password, useSandbox = false) {
  return FlixInpageModule.initialize({ username, password, useSandbox });
}

export function getInpageHtml(productParams, baseUrl = 'https://www.example.com') {
  return FlixInpageModule.getInpageHtml({ productParams, baseUrl });
}

let flixWebviewRefGlobal = null;
const EXTERNAL_BROWSER_FILE_REGEX = /\.(pdf|docx?|usdz)(?:$|[?#&])/i;
const SCENE_VIEWER_URL_REGEX = /^https?:\/\/arvr\.google\.com\/scene-viewer(?:[/?#]|$)/i;
const INTENT_URL_REGEX = /^intent:/i;

export function setWebViewRef(ref) {
  flixWebviewRefGlobal = ref;
}

function clearWebViewRef(ref) {
  if (flixWebviewRefGlobal === ref) {
    flixWebviewRefGlobal = null;
  }
}

export function sendMessageToWebView(message) {
  if (!flixWebviewRefGlobal || typeof message !== 'string') return;

  const js = `
    try {
      window.flixtracking &&
      window.flixtracking.onLogFromApp(${JSON.stringify(message)});
    } catch(e){}
    true;
  `;

  flixWebviewRefGlobal.injectJavaScript(js);
}

function shouldOpenInExternalBrowser(url) {
  if (!url) return false;
  const normalizedUrl = String(url).trim().replace(/&amp;/gi, '&');
  return (
    EXTERNAL_BROWSER_FILE_REGEX.test(normalizedUrl) ||
    SCENE_VIEWER_URL_REGEX.test(normalizedUrl) ||
    INTENT_URL_REGEX.test(normalizedUrl)
  );
}

/* ============================================================================
 * Hook: useFlixViewportTracking
 * ========================================================================== */

function useFlixViewportTracking({ containerRef, webviewRef }) {
  const lastSentRef = useRef(0);
  const pendingMeasureRef = useRef(false);
  const lastMetricsRef = useRef({ topOffset: -1, visibleHeight: -1 });
  const THROTTLE_MS = 50;

  const sendViewportMetrics = useCallback(() => {
    if (!containerRef.current || !webviewRef.current) return;

    const now = Date.now();
    if (now - lastSentRef.current < THROTTLE_MS) return;
    if (pendingMeasureRef.current) return;
    lastSentRef.current = now;
    pendingMeasureRef.current = true;

    containerRef.current.measureInWindow((x, y, width, height) => {
      pendingMeasureRef.current = false;
      const viewportHeight = Dimensions.get('window').height;

      const webTop = y;
      const webBottom = y + height;

      const intersectionTop = Math.max(webTop, 0);
      const intersectionBottom = Math.min(webBottom, viewportHeight);

      if (intersectionBottom <= intersectionTop) return;

      const topOffset = intersectionTop - webTop;
      const visibleHeight = intersectionBottom - intersectionTop;
      const lastMetrics = lastMetricsRef.current;

      if (
        Math.abs(topOffset - lastMetrics.topOffset) < 1 &&
        Math.abs(visibleHeight - lastMetrics.visibleHeight) < 1
      ) {
        return;
      }

      lastMetricsRef.current = { topOffset, visibleHeight };

      const js = `
        (function(){
          try {
            if (window.flixtracking &&
                typeof window.flixtracking.onScrollFromApp === 'function') {
              window.flixtracking.onScrollFromApp(
                ${topOffset.toFixed(2)},
                ${visibleHeight.toFixed(2)}
              );
            }
          } catch(e){}
        })();
        true;
      `;

      webviewRef.current.injectJavaScript(js);
    });
  }, [containerRef, webviewRef]);

  return { sendViewportMetrics };
}

/* ============================================================================
 * Component: InpageHtmlView
 * ========================================================================== */

export const InpageHtmlView = forwardRef(({
  productParams = {},
  baseUrl = 'https://www.example.com',
  style,
  showLoader = false,
  parentScrollRef,
  onError,
  onLoadedHtml,
}, ref) => {
  const [htmlState, setHtmlState] = useState({ key: null, html: null });
  const [loading, setLoading] = useState(true);
  const [webviewHeight, setWebviewHeight] = useState(50);

  const webviewRef = useRef(null);
  const containerRef = useRef(null);
  const lastHeightRef = useRef(0);
  const scrollYRef = useRef(0);
  const isProgrammaticScrollRef = useRef(false);
  const productParamsKey = useMemo(
    () => JSON.stringify(productParams),
    [productParams],
  );
  const webviewKey = useMemo(
    () => `${baseUrl}:${productParamsKey}`,
    [baseUrl, productParamsKey],
  );
  const containerStyle = useMemo(
    () => [{ width: '100%', height: webviewHeight, overflow: 'hidden' }, style],
    [webviewHeight, style],
  );
  const webviewSource = useMemo(
    () => (
      htmlState.key === webviewKey && htmlState.html
        ? { html: htmlState.html, baseUrl }
        : { html: '<html><body></body></html>' }
    ),
    [htmlState, webviewKey, baseUrl],
  );

  const { sendViewportMetrics } = useFlixViewportTracking({
    containerRef,
    webviewRef,
  });

  /* expose to parent */
  useImperativeHandle(ref, () => ({
    onParentScroll: (event) => {
      if (event?.nativeEvent?.contentOffset?.y != null) {
        scrollYRef.current = event.nativeEvent.contentOffset.y;
      }
      sendViewportMetrics();
    },
  }), [sendViewportMetrics]);

  /* load html */
  useEffect(() => {
    let mounted = true;
    const requestKey = webviewKey;

    setHtmlState({ key: null, html: null });
    setLoading(true);
    setWebviewHeight(50);
    lastHeightRef.current = 0;

    (async () => {
      try {
        const htmlResponse = await getInpageHtml(productParams, baseUrl);
        if (!mounted) return;

        if (!htmlResponse) {
          onError?.('No HTML from SDK');
          return;
        }

        const nextHtml = String(htmlResponse);
        setHtmlState({ key: requestKey, html: nextHtml });
        onLoadedHtml?.(nextHtml);
      } catch (e) {
        onError?.(String(e));
      } finally {
        mounted && setLoading(false);
      }
    })();

    return () => { mounted = false; };
  }, [productParamsKey, baseUrl, webviewKey]);

  useEffect(() => (
    () => {
      clearWebViewRef(webviewRef.current);
      webviewRef.current = null;
    }
  ), []);

  /* re-send on resize */
  useEffect(() => {
    if (webviewHeight > 1) {
      requestAnimationFrame(sendViewportMetrics);
    }
  }, [webviewHeight, sendViewportMetrics]);

  const confirmAndOpenExternalLink = useCallback((url) => {
    Alert.alert(
      'Leave the app?',
      'You are about to open an external link in your browser.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Open',
          style: 'destructive',
          onPress: () => {
            if (Platform.OS === 'ios') {
              FlixInpageModule.openURL(url).catch(() => {});
            } else {
              Linking.openURL(url).catch(() => {});
            }
          },
        },
      ]
    );
  }, []);

  const handleScrollToViewport = useCallback((viewportTop, animated = true) => {
    if (!containerRef.current || !parentScrollRef?.current) return;
    if (isProgrammaticScrollRef.current) return;

    containerRef.current.measureInWindow((_x, y) => {
      const mediaTop = 0; // RN handles status bar internally
      const appBarHeight = 0; // jeśli masz custom header → wstrzyknij

      const scrollOffset =
        scrollYRef.current +
        y +
        viewportTop -
        mediaTop -
        appBarHeight;

      isProgrammaticScrollRef.current = true;
      setTimeout(
        () => { isProgrammaticScrollRef.current = false; },
        animated ? 500 : 100,
      );

      try {
        parentScrollRef.current.scrollTo({
          y: scrollOffset,
          animated,
        });
      } catch (e) {}
    });
  }, [parentScrollRef]);

  const injectedJS = useMemo(() => `
(function () {
  function shouldOpenExternally(url) {
    if (!url) return false;
    var normalizedUrl = String(url).trim().replace(/&amp;/gi, '&');
    return (
      /\.(pdf|docx?|usdz)(?:$|[?#&])/i.test(normalizedUrl) ||
      /^https?:\\/\\/arvr\\.google\\.com\\/scene-viewer(?:[/?#]|$)/i.test(normalizedUrl) ||
      /^intent:/i.test(normalizedUrl)
    );
  }

  /* ============================
   * HEIGHT / RESIZE OBSERVER
   * ============================ */

  var lastHeight = -1; // ensures first send always happens
  var heightRaf = null;

  function sendHeight() {
    try {
      var h =
        document.body.scrollHeight ||
        document.documentElement.scrollHeight ||
        1;

      h = Math.ceil(h);

      if (lastHeight !== -1 && Math.abs(h - lastHeight) < 2) {
        return;
      }

      lastHeight = h;

      window.ReactNativeWebView.postMessage(
        JSON.stringify({
          type: 'height',
          height: h,
        })
      );
    } catch (e) {}
  }

  function scheduleHeightSend() {
    if (heightRaf != null) return;
    heightRaf = requestAnimationFrame(function () {
      heightRaf = null;
      sendHeight();
    });
  }

  try {
    var mo = new MutationObserver(function () {
      scheduleHeightSend();
    });

    mo.observe(document.body, {
      childList: true,
      subtree: true,
      attributes: true,
    });
  } catch (e) {}

  window.addEventListener('load', function () {
    sendHeight();
  });

  // initial send
  sendHeight();

  /* ============================
   * LINK INTERCEPTOR (iOS SAFE)
   * ============================ */
  document.addEventListener(
    'click',
    function (event) {
      try {
        var clicked = event.target;
        var dataLinkNode = clicked && clicked.closest
          ? clicked.closest('[data-link]')
          : null;

        if (dataLinkNode) {
          var dataLinkValue = dataLinkNode.getAttribute('data-link');
          if (!dataLinkValue) return;

          var dataLinkUrl = '';
          try {
            dataLinkUrl = new URL(dataLinkValue, window.location.href).toString();
          } catch (_) {
            return;
          }

          event.preventDefault();
          event.stopPropagation();
          event.stopImmediatePropagation();

          window.ReactNativeWebView.postMessage(
            JSON.stringify({
              type: 'external-link',
              url: dataLinkUrl,
              forceExternal: true,
            })
          );
          return;
        }

        var el = clicked;
        while (el && el.tagName !== 'A') {
          el = el.parentElement;
        }

        if (!el) return;

        var href = el.getAttribute('href');
        if (!href) return;

        if (
          href === '#' ||
          href.startsWith('javascript:') ||
          href.startsWith('data:')
        ) {
          return;
        }

        if (href.startsWith('/') || href.startsWith('#')) {
          return;
        }

        if (!shouldOpenExternally(el.href)) {
          return;
        }

        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation();

        window.ReactNativeWebView.postMessage(
          JSON.stringify({
            type: 'external-link',
            url: el.href,
          })
        );
      } catch (e) {}
    },
    true
  );

  /* ============================
   * BLOCK window.open / target=_blank
   * ============================ */
  try {
    window.open = function (url) {
      if (url) {
        if (shouldOpenExternally(url)) {
          window.ReactNativeWebView.postMessage(
            JSON.stringify({
              type: 'external-link',
              url: url,
            })
          );
        } else {
          window.location.href = url;
        }
      }
      return null;
    };
  } catch (e) {}

  /* ============================
 * SCROLL TO VIEWPORT (JS → APP)
 * ============================ */
  if (!window.flixtracking) {
    window.flixtracking = {};
  }

  window.flixtracking.scrollToViewport = function (viewportTop, animated) {
    try {
      window.ReactNativeWebView.postMessage(
        JSON.stringify({
          type: 'scroll-to-viewport',
          viewportTop: Number(viewportTop) || 0,
          animated: animated !== false,
        })
      );
    } catch (e) {}
  };
})();
true;
`, []);

  const onMessage = useCallback((event) => {
    try {
      const data = JSON.parse(event.nativeEvent.data);

      if (data.type === 'height') {
        const h = Math.max(1, data.height);
        if (h !== lastHeightRef.current) {
          lastHeightRef.current = h;
          setWebviewHeight(h);
        }
      }

      if (data.type === 'external-link') {
        if (data.forceExternal || shouldOpenInExternalBrowser(data.url)) {
          confirmAndOpenExternalLink(data.url);
        }
      }

      if (data.type === 'scroll-to-viewport') {
        handleScrollToViewport(data.viewportTop, data.animated);
        return;
      }
    } catch (_) {}
  }, [confirmAndOpenExternalLink, handleScrollToViewport]);

  const onLoadEnd = useCallback(() => {
    requestAnimationFrame(sendViewportMetrics);
  }, [sendViewportMetrics]);

  const onShouldStartLoadWithRequest = useCallback((request) => {
    if (shouldOpenInExternalBrowser(request.url)) {
      confirmAndOpenExternalLink(request.url);
      return false;
    }
    return true;
  }, [confirmAndOpenExternalLink]);

  const setWebViewInstance = useCallback((webview) => {
    if (webview === null) {
      clearWebViewRef(webviewRef.current);
      webviewRef.current = null;
      return;
    }

    webviewRef.current = webview;
    setWebViewRef(webview);
  }, []);

  return (
    <View
      ref={containerRef}
      style={containerStyle}
    >
      {loading && showLoader && (
        <View style={styles.loaderOverlay}>
          <ActivityIndicator size="small" />
        </View>
      )}

      <WebView
        key={webviewKey}
        ref={setWebViewInstance}
        source={webviewSource}
        injectedJavaScript={injectedJS}
        onMessage={onMessage}
        onLoadEnd={onLoadEnd}
        onShouldStartLoadWithRequest={onShouldStartLoadWithRequest}
        scrollEnabled={false}
        javaScriptEnabled
        domStorageEnabled
        webviewDebuggingEnabled={__DEV__}
        allowsInlineMediaPlayback
        mediaPlaybackRequiresUserAction={false}
        style={styles.webview}
      />
    </View>
  );
});

/* ============================================================================
 * Styles
 * ========================================================================== */

const styles = StyleSheet.create({
  loaderOverlay: {
    ...StyleSheet.absoluteFillObject,
    zIndex: 2,
    justifyContent: 'center',
    alignItems: 'center',
  },
  webview: {
    backgroundColor: 'transparent',
  },
});
