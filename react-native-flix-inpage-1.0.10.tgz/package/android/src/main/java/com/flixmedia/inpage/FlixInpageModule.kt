package com.flixmedia.inpage

import com.facebook.react.bridge.*
import com.flixmedia.flixmediasdk.FlixMedia
import com.flixmedia.flixmediasdk.WebViewConfiguration
import com.flixmedia.flixmediasdk.models.ProductRequestParameters
import kotlinx.coroutines.*
import java.net.URL

class FlixInpageModule(
    reactContext: ReactApplicationContext
) : ReactContextBaseJavaModule(reactContext) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun getName(): String = "FlixInpageModule"

    // --- initialize ---
    @ReactMethod
    fun initialize(params: ReadableMap, promise: Promise) {
        val username = params.getString("username")
        val password = params.getString("password")
        val useSandbox = if (params.hasKey("useSandbox")) {
            params.getBoolean("useSandbox")
        } else {
            false
        }

        if (username.isNullOrBlank() || password.isNullOrBlank()) {
            promise.reject("ARG_ERR", "Missing username or password")
            return
        }

        scope.launch {
            try {
                FlixMedia.initialize(
                    context = reactApplicationContext,
                    username = username,
                    password = password,
                    useSandbox = useSandbox
                )

                withContext(Dispatchers.Main) {
                    promise.resolve(null)
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    promise.reject("INIT_ERR", e.message, e)
                }
            }
        }
    }

    // --- getInpageHtml ---
    @ReactMethod
    fun getInpageHtml(params: ReadableMap, promise: Promise) {
        if (!params.hasKey("productParams")) {
            promise.reject("ARG_ERR", "Missing productParams")
            return
        }
        val requestedBaseUrl = if (params.hasKey("baseUrl")) {
            params.getString("baseUrl") ?: "https://www.example.com"
        } else {
            "https://www.example.com"
        }

        try {
            val baseUrl = try {
                URL(requestedBaseUrl)
                requestedBaseUrl
            } catch (e: Exception) {
                "https://www.example.com"
            }

            val productParamsMap = params.getMap("productParams") ?: run {
                promise.reject("ARG_ERR", "Invalid productParams")
                return
            }

            val product = ProductRequestParameters(
                mpn = productParamsMap.getStringValue("mpn"),
                ean = productParamsMap.getStringValue("ean"),
                distId = productParamsMap.getStringValue("distributorId"),
                isoCode = productParamsMap.getStringValue("isoCode"),
                flIsoCode = productParamsMap.getStringValue("flIsoCode"),
                brand = productParamsMap.getStringValue("brand"),
                title = productParamsMap.getStringValue("title"),
                price = productParamsMap.getStringValue("price"),
                currency = productParamsMap.getStringValue("currency")
            )

            val config = WebViewConfiguration(
                params = product,
                baseURL = baseUrl
            )

            scope.launch {
                try {
                    val html = FlixMedia.loadHTML(
                        context = reactApplicationContext,
                        configuration = config
                    )

                    withContext(Dispatchers.Main) {
                        promise.resolve(html)
                    }
                } catch (e: Exception) {
                    withContext(Dispatchers.Main) {
                        promise.reject("HTML_ERR", e.message, e)
                    }
                }
            }

        } catch (e: Exception) {
            promise.reject("HTML_ERR", e.message, e)
        }
    }

    override fun invalidate() {
        super.invalidate()
        scope.cancel()
    }

    private fun ReadableMap.getStringValue(key: String): String {
        if (!hasKey(key) || isNull(key)) {
            return ""
        }

        return when (getType(key)) {
            ReadableType.String -> getString(key) ?: ""
            ReadableType.Number -> {
                val value = getDouble(key)
                if (value % 1.0 == 0.0) value.toLong().toString() else value.toString()
            }
            ReadableType.Boolean -> getBoolean(key).toString()
            else -> ""
        }
    }
}
