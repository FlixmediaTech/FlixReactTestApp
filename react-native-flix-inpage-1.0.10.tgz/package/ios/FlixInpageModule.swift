import Foundation
import UIKit
import FlixMediaSDK

@objc(FlixInpageModule)
class FlixInpageModule: NSObject {

  @objc(openURL:resolver:rejecter:)
  func openURL(urlString: String, resolver resolve: @escaping RCTPromiseResolveBlock, rejecter reject: @escaping RCTPromiseRejectBlock) {
    guard let url = URL(string: urlString) else {
      reject("INVALID_URL", "Cannot parse URL: \(urlString)", nil)
      return
    }
    DispatchQueue.main.async {
      UIApplication.shared.open(url, options: [:]) { success in
        if success {
          resolve(nil)
        } else {
          reject("OPEN_FAILED", "UIApplication could not open URL: \(urlString)", nil)
        }
      }
    }
  }

  // MARK: - exported methods (async -> Promise)
  @objc(initialize:resolver:rejecter:)
  func initialize(params: NSDictionary, resolver resolve: @escaping RCTPromiseResolveBlock, rejecter reject: @escaping RCTPromiseRejectBlock) {
    Task {
      do {
        guard let username = params["username"] as? String,
              let password = params["password"] as? String else {
          reject("ARG_ERR", "Missing username or password", nil)
          return
        }
        
        let useSandbox = params["useSandbox"] as? Bool ?? false

        try await FlixMedia.shared.initialize(
          username: username,
          password: password,
          useSandbox: useSandbox
        )
        resolve(nil)
      } catch {
        reject("INIT_ERR", error.localizedDescription, error)
      }
    }
  }

  @objc(getInpageHtml:resolver:rejecter:)
  func getInpageHtml(params: NSDictionary, resolver resolve: @escaping RCTPromiseResolveBlock, rejecter reject: @escaping RCTPromiseRejectBlock) {
    Task {
      do {
        guard let productParams = params["productParams"] as? NSDictionary else {
          reject("ARG_ERR", "Missing productParams", nil)
          return
        }
        let defaultBaseUrl = URL(string: "https://www.example.com")!
        let baseUrlString = (params["baseUrl"] as? String) ?? defaultBaseUrl.absoluteString
        let baseUrl = URL(string: baseUrlString) ?? defaultBaseUrl

        let product = ProductRequestParameters(
          mpn: stringValue(productParams["mpn"]),
          ean: stringValue(productParams["ean"]),
          distId: stringValue(productParams["distributorId"]),
          isoCode: stringValue(productParams["isoCode"]),
          flIsoCode: stringValue(productParams["flIsoCode"]),
          brand: stringValue(productParams["brand"]),
          title: stringValue(productParams["title"]),
          price: stringValue(productParams["price"]),
          currency: stringValue(productParams["currency"])
        )

        let config = WebViewConfiguration(productParams: product, baseURL: baseUrl)
        let html = try await FlixMedia.shared.loadHTML(configuration: config)
        resolve(html)
      } catch {
        reject("HTML_ERR", error.localizedDescription, error)
      }
    }
  }

  @objc
  static func requiresMainQueueSetup() -> Bool {
    return false
  }

  private func stringValue(_ value: Any?) -> String {
    if let string = value as? String {
      return string
    }

    if let number = value as? NSNumber {
      return number.stringValue
    }

    return ""
  }
}
