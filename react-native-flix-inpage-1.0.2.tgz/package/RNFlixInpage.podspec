Pod::Spec.new do |s|
  s.name         = 'RNFlixInpage'
  s.version      = '1.0.2'
  s.summary      = 'React Native iOS bridge for FlixMediaSDK'
  s.platform     = :ios, '15.6'
  s.vendored_frameworks = 'ios/Frameworks/FlixMediaSDK.xcframework'
  s.source_files = 'ios/*.{swift,h,m}' 
  s.static_framework = true
  s.swift_version = '5.10'
  s.dependency 'React-Core'

  s.homepage     = 'https://www.flixmedia.com'
  s.license      = { :type => 'MIT', :file => 'LICENSE' }
  s.author       = { 'Flixmedia' => 'prioritysupport@flixmedia.tv' }
  s.source       = { :path => '.' }

  s.pod_target_xcconfig = {
    'DEFINES_MODULE' => 'YES',
    'SWIFT_STRICT_CONCURRENCY' => 'minimal',
    'EXCLUDED_ARCHS[sdk=iphonesimulator*]' => 'i386'
  }
end
