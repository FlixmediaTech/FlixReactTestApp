import React, { useEffect, useState, useRef } from 'react';
import { NativeModules } from 'react-native';
import { View, ActivityIndicator, StyleSheet } from 'react-native';
import { WebView } from 'react-native-webview';

const { FlixInpageModule } = NativeModules;

export function initialize(username, password, useSandbox = false) {
  return FlixInpageModule.initialize({ username, password, useSandbox });
}

export function getInpageHtml(productParams) {
  return FlixInpageModule.getInpageHtml({ productParams });
}

let flixWebviewRefGlobal = null;

export function setWebViewRef(ref) {
  flixWebviewRefGlobal = ref;
}

export function sendMessageToWebView(message) {
  if (flixWebviewRefGlobal && typeof message === 'string') {
    const escapedMessage = message
      .replace(/\\/g, '\\\\')
      .replace(/`/g, '\\`')
      .replace(/\$/g, '\\$');
    const jsToInject = `window.flixtracking && window.flixtracking.onLogFromApp(\`${escapedMessage}\`); true;`;
    flixWebviewRefGlobal.injectJavaScript(jsToInject);
  }
}

/**
 * InpageHtmlView
 * - Renders only the WebView.
 * - Outer app must call initialize(...) before rendering this component.
 *
 * Props:
 * - productParams: passed to getInpageHtml()
 * - baseUrl: baseUrl for WebView source
 * - style: wrapper style (height is controlled dynamically)
 * - onError(htmlOrError): optional callback on error
 * - onLoadedHtml(html): optional callback on HTML load
 * - showLoader: show ActivityIndicator while loading (default true)
 */
export function InpageHtmlView({
  productParams = {},
  baseUrl = 'https://example.com',
  style,
  onError,
  onLoadedHtml,
  showLoader = true,
}) {
  const [html, setHtml] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [webviewHeight, setWebviewHeight] = useState(50);
  const lastHeightRef = useRef(0);
  const webviewRef = useRef(null);

  useEffect(() => {
    let mounted = true;

    async function load() {
      try {
        const htmlResponse = await getInpageHtml(productParams);
        if (!mounted) return;
        if (!htmlResponse) {
          const msg = 'No HTML data from SDK';
          setError(msg);
          if (onError) onError(msg);
        } else {
          const htmlString = String(htmlResponse);
          setHtml(htmlString);
          if (onLoadedHtml) onLoadedHtml(htmlString);
        }
      } catch (e) {
        const msg = e && e.message ? e.message : String(e);
        if (!mounted) return;
        setError(msg);
        if (onError) onError(msg);
      } finally {
        if (mounted) setLoading(false);
      }
    }

    load();
    return () => { mounted = false; };
  }, [JSON.stringify(productParams)]);

  const injectedResizeObserverJS = `
    function sendResizeMessage() {
      try { 
        var h = document.body.scrollHeight || document.documentElement.scrollHeight || 1;
        window.ReactNativeWebView.postMessage(JSON.stringify({ type: 'height', height: Math.ceil(h) }));
      } catch (e) {}
    }
    const observer = new MutationObserver(function(mutations) { sendResizeMessage(); });
    observer.observe(document.body, { childList: true, subtree: true, attributes: true });
    window.addEventListener("load", sendResizeMessage);
    sendResizeMessage();
    true;
  `;

  function onWebViewMessage(event) {
    try {
      const data = JSON.parse(event.nativeEvent.data);
      if (data && data.type === 'height' && typeof data.height === 'number') {
        const newHeight = Math.max(1, Math.round(data.height));
        if (newHeight !== lastHeightRef.current) {
          lastHeightRef.current = newHeight;
          setWebviewHeight(newHeight);
        }
      }
    } catch (e) {
      // ignore malformed messages
    }
  }

  return (
    <View style={[{ width: '100%', overflow: 'hidden', height: webviewHeight }, style]}>
      {loading && showLoader && (
        <View style={styles.loaderOverlay}>
          <ActivityIndicator size="small" />
        </View>
      )}

      <WebView
        ref={ref => {
          webviewRef.current = ref;
          setWebViewRef(ref);
        }}
        originWhitelist={['*']}
        source={html ? { html: html, baseUrl } : { html: '<!doctype html><html><body></body></html>' }}
        injectedJavaScript={injectedResizeObserverJS}
        onMessage={onWebViewMessage}
        scrollEnabled={false}
        style={{ flex: 1, backgroundColor: 'transparent' }}
        javaScriptEnabled={true}
        domStorageEnabled={true}
        webviewDebuggingEnabled={true}
        allowsInlineMediaPlayback={true}
        mediaPlaybackRequiresUserAction={false} 
      />
    </View>
  );
}

const styles = StyleSheet.create({
  loaderOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    zIndex: 2,
    justifyContent: 'center',
    alignItems: 'center',
  },
});
