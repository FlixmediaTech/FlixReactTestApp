package com.flixmedia.inpage

import com.facebook.react.bridge.*
import com.flixmedia.flixmediasdk.FlixMedia
import com.flixmedia.flixmediasdk.WebViewConfiguration
import com.flixmedia.flixmediasdk.content.FlixMediaError
import com.flixmedia.flixmediasdk.models.ProductRequestParameters
import kotlinx.coroutines.*
import org.json.JSONObject
import com.google.gson.Gson
import java.net.URL

class FlixInpageModule(
    reactContext: ReactApplicationContext
) : ReactContextBaseJavaModule(reactContext) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val gson = Gson()

    override fun getName(): String = "FlixInpageModule"

    // --- initialize ---
    @ReactMethod
    fun initialize(params: ReadableMap, promise: Promise) {
        val username = params.getString("username")
        val password = params.getString("password")
        val useSandbox = if (params.hasKey("useSandbox")) {
            params.getBoolean("useSandbox")
        } else {
            false
        }

        if (username.isNullOrBlank() || password.isNullOrBlank()) {
            promise.reject("ARG_ERR", "Missing username or password")
            return
        }

        scope.launch {
            try {
                FlixMedia.initialize(
                    context = reactApplicationContext,
                    username = username,
                    password = password,
                    useSandbox = useSandbox
                )

                withContext(Dispatchers.Main) {
                    promise.resolve(null)
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    promise.reject("INIT_ERR", e.message, e)
                }
            }
        }
    }

    @ReactMethod
    fun initializeWithToken(params: ReadableMap, promise: Promise) {
        val idToken = params.getString("idToken")
        val useSandbox = if (params.hasKey("useSandbox")) {
            params.getBoolean("useSandbox")
        } else {
            false
        }

        if (idToken.isNullOrBlank()) {
            promise.reject("ARG_ERR", "Missing idToken")
            return
        }

        scope.launch {
            try {
                FlixMedia.initialize(
                    context = reactApplicationContext,
                    idToken = idToken,
                    expiresAt = params.normalizedExpiresAt(),
                    useSandbox = useSandbox
                )

                withContext(Dispatchers.Main) {
                    promise.resolve(null)
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    promise.reject("INIT_TOKEN_ERR", e.message, e)
                }
            }
        }
    }

    @ReactMethod
    fun updateToken(params: ReadableMap, promise: Promise) {
        val idToken = params.getString("idToken")

        if (idToken.isNullOrBlank()) {
            promise.reject("ARG_ERR", "Missing idToken")
            return
        }

        scope.launch {
            try {
                FlixMedia.updateToken(
                    context = reactApplicationContext,
                    idToken = idToken,
                    expiresAt = params.normalizedExpiresAt()
                )

                withContext(Dispatchers.Main) {
                    promise.resolve(null)
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    promise.reject("UPDATE_TOKEN_ERR", e.message, e)
                }
            }
        }
    }

    // --- getInpageHtml ---
    @ReactMethod
    fun getInpageHtml(params: ReadableMap, promise: Promise) {
        if (!params.hasKey("productParams")) {
            promise.reject("ARG_ERR", "Missing productParams")
            return
        }
        val requestedBaseUrl = if (params.hasKey("baseUrl")) {
            params.getString("baseUrl") ?: "https://www.example.com"
        } else {
            "https://www.example.com"
        }

        try {
            val baseUrl = try {
                URL(requestedBaseUrl)
                requestedBaseUrl
            } catch (e: Exception) {
                "https://www.example.com"
            }

            val productParamsMap = params.getMap("productParams") ?: run {
                promise.reject("ARG_ERR", "Invalid productParams")
                return
            }

            // ReadableMap -> JSON -> DTO (jak w Swift)
            val rawMap = productParamsMap.toHashMap() as HashMap<String, Any?>
            val json = JSONObject(rawMap as Map<*, *>).toString()
            val dto = gson.fromJson(json, ProductRequestParametersDTO::class.java)

            val product = ProductRequestParameters(
                mpn = dto.mpn ?: "",
                ean = dto.ean ?: "",
                distId = dto.distributorId ?: "",
                isoCode = dto.isoCode ?: "",
                flIsoCode = dto.flIsoCode ?: "",
                brand = dto.brand ?: "",
                title = dto.title ?: "",
                price = dto.price ?: "",
                currency = dto.currency ?: ""
            )

            val config = WebViewConfiguration(
                params = product,
                baseURL = baseUrl
            )

            scope.launch {
                try {
                    val html = FlixMedia.loadHTML(
                        context = reactApplicationContext,
                        configuration = config
                    )

                    withContext(Dispatchers.Main) {
                        promise.resolve(html)
                    }
                } catch (e: FlixMediaError.TokenExpired) {
                    withContext(Dispatchers.Main) {
                        promise.reject("TOKEN_EXPIRED", e.message, e)
                    }
                } catch (e: Exception) {
                    withContext(Dispatchers.Main) {
                        promise.reject("HTML_ERR", e.message, e)
                    }
                }
            }

        } catch (e: Exception) {
            promise.reject("HTML_ERR", e.message, e)
        }
    }

    override fun invalidate() {
        super.invalidate()
        scope.cancel()
    }

    private fun ReadableMap.normalizedExpiresAt(): Long? {
        if (!hasKey("expiresAt") || isNull("expiresAt")) {
            return null
        }

        return when (getType("expiresAt")) {
            ReadableType.Number -> getDouble("expiresAt").toLong()
            ReadableType.String -> getString("expiresAt")?.toLongOrNull()
            else -> null
        }
    }
}

data class ProductRequestParametersDTO(
    val mpn: String? = null,
    val ean: String? = null,
    val distributorId: String? = null,
    val isoCode: String? = null,
    val flIsoCode: String? = null,
    val brand: String? = null,
    val title: String? = null,
    val price: String? = null,
    val currency: String? = null
)
