# react-native-flix-inpage

React Native bridge for the FlixMedia SDK, used to fetch and render FlixMedia product HTML in-app.

## Features
- Native bridge to FlixMedia SDK (iOS + Android)
- `initialize` for SDK authentication
- `initializeWithTokenProvider` for retailer-managed tokens
- `getInpageHtml` for direct HTML retrieval
- `InpageHtmlView` component based on `react-native-webview`

## Compatibility
- React Native: `>=0.41.2` (from `peerDependencies`)
- iOS deployment target: `15.6` (from podspec)
- Android `minSdkVersion`: `23`

## Installation

Install the package:

```bash
npm install react-native-flix-inpage
```

If you are testing from a local package path instead of registry:

```bash
npm install /path/to/react-native-flix-inpage
```

Install peer dependency if missing:

```bash
npm install react-native-webview
```

## API

```js
import {
  initialize,
  initializeWithTokenProvider,
  getInpageHtml,
  InpageHtmlView,
  setWebViewRef,
  sendMessageToWebView,
} from 'react-native-flix-inpage';
```

### `initialize(username, password, useSandbox = false)`

```js
await initialize('username', 'password');
// or:
await initialize('username', 'password', true); // sandbox
```

### `initializeWithTokenProvider(tokenProvider, useSandbox = false)`

```js
await initializeWithTokenProvider(async () => {
  const token = await retailerBackend.fetchFlixToken();

  return {
    idToken: token.idToken,
    expiresAt: token.expiresAt, // Unix timestamp in seconds or ISO-8601 string.
  };
});
```

When native SDK reports expired token while loading content, `getInpageHtml`
calls same provider again, updates SDK token, and retries once.

### `getInpageHtml(productParams, baseUrl = 'https://www.example.com')`

```js
const html = await getInpageHtml({
  mpn: '',
  ean: '',
  distributorId: '0',
  isoCode: '',
  flIsoCode: '',
  brand: '',
  title: '',
  price: '',
  currency: '',
}, 'https://www.your-store-domain.com');
```

### `InpageHtmlView`

```jsx
<ScrollView>
  <InpageHtmlView
    productParams={{
      mpn: '',
      ean: '',
      distributorId: '0',
      isoCode: '',
      flIsoCode: '',
      brand: '',
      title: '',
      price: '',
      currency: '',
    }}
    style={{ backgroundColor: 'white' }}
    onError={(err) => console.warn('Inpage error:', err)}
    onLoadedHtml={(html) => console.log('Inpage loaded, length:', html.length)}
    onShouldOpenExternalLink={(url) => true}
  />
</ScrollView>
```

`onShouldOpenExternalLink` is optional. When provided, it replaces the default
confirmation alert for browser links. Return `true` to open the link in the
browser, or `false` to cancel it.

## License
MIT
