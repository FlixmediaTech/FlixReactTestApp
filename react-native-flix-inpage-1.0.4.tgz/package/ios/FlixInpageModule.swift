import Foundation
import FlixMediaSDK

@objc(FlixInpageModule)
class FlixInpageModule: NSObject {

  // MARK: - exported methods (async -> Promise)
  @objc(initialize:resolver:rejecter:)
  func initialize(params: NSDictionary, resolver resolve: @escaping RCTPromiseResolveBlock, rejecter reject: @escaping RCTPromiseRejectBlock) {
    Task {
      do {
        guard let username = params["username"] as? String,
              let password = params["password"] as? String else {
          reject("ARG_ERR", "Missing username or password", nil)
          return
        }
        
        let useSandbox = params["useSandbox"] as? Bool ?? false

        try await FlixMedia.shared.initialize(
          username: username,
          password: password,
          useSandbox: useSandbox
        )
        resolve(nil)
      } catch {
        reject("INIT_ERR", error.localizedDescription, error)
      }
    }
  }

  @objc(getInpageHtml:resolver:rejecter:)
  func getInpageHtml(params: NSDictionary, resolver resolve: @escaping RCTPromiseResolveBlock, rejecter reject: @escaping RCTPromiseRejectBlock) {
    Task {
      do {
        guard let productParams = params["productParams"] as? NSDictionary else {
          reject("ARG_ERR", "Missing productParams", nil)
          return
        }

        let jsonData = try JSONSerialization.data(withJSONObject: productParams, options: [])
        let dto = try JSONDecoder().decode(ProductRequestParametersDTO.self, from: jsonData)

        let product = ProductRequestParameters(
          mpn: dto.mpn ?? "",
          ean: dto.ean ?? "",
          distId: dto.distributorId ?? "",
          isoCode: dto.isoCode ?? "",
          flIsoCode: dto.flIsoCode ?? "",
          brand: dto.brand ?? "",
          title: dto.title ?? "",
          price: dto.price ?? "",
          currency: dto.currency ?? ""
        )

        let config = WebViewConfiguration(productParams: product, baseURL: URL(string: "https://www.example.com")!)
        let html = try await FlixMedia.shared.loadHTML(configuration: config)
        resolve(html)
      } catch {
        reject("HTML_ERR", error.localizedDescription, error)
      }
    }
  }

  @objc
  static func requiresMainQueueSetup() -> Bool {
    return false
  }
}

fileprivate struct ProductRequestParametersDTO: Decodable {
  let mpn: String?
  let ean: String?
  let distributorId: String?
  let isoCode: String?
  let flIsoCode: String?
  let brand: String?
  let title: String?
  let price: String?
  let currency: String?

  enum CodingKeys: String, CodingKey {
    case mpn, ean, distributorId, isoCode, flIsoCode, brand, title, price, currency
  }

  init(from decoder: Decoder) throws {
    let c = try decoder.container(keyedBy: CodingKeys.self)
    mpn = try c.decodeIfPresent(String.self, forKey: .mpn)
    ean = try c.decodeIfPresent(String.self, forKey: .ean)

    if let s = try? c.decode(String.self, forKey: .distributorId) {
      distributorId = s
    } else if let n = try? c.decode(Int.self, forKey: .distributorId) {
      distributorId = String(n)
    } else {
      distributorId = nil
    }

    isoCode = try c.decodeIfPresent(String.self, forKey: .isoCode)
    flIsoCode = try c.decodeIfPresent(String.self, forKey: .flIsoCode)
    brand = try c.decodeIfPresent(String.self, forKey: .brand)
    title = try c.decodeIfPresent(String.self, forKey: .title)
    price = try c.decodeIfPresent(String.self, forKey: .price)
    currency = try c.decodeIfPresent(String.self, forKey: .currency)
  }
}
