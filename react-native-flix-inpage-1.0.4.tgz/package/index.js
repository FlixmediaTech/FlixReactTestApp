import React, {
  useEffect,
  useState,
  useRef,
  forwardRef,
  useImperativeHandle,
} from 'react';
import {
  View,
  ActivityIndicator,
  StyleSheet,
  Alert,
  Linking,
  Dimensions,
  NativeModules,
} from 'react-native';
import { WebView } from 'react-native-webview';

const { FlixInpageModule } = NativeModules;

/* ============================================================================
 * SDK API
 * ========================================================================== */

export function initialize(username, password, useSandbox = false) {
  return FlixInpageModule.initialize({ username, password, useSandbox });
}

export function getInpageHtml(productParams) {
  return FlixInpageModule.getInpageHtml({ productParams });
}

let flixWebviewRefGlobal = null;

export function setWebViewRef(ref) {
  flixWebviewRefGlobal = ref;
}

export function sendMessageToWebView(message) {
  if (!flixWebviewRefGlobal || typeof message !== 'string') return;

  const escaped = message
    .replace(/\\/g, '\\\\')
    .replace(/`/g, '\\`')
    .replace(/\$/g, '\\$');

  const js = `
    try {
      window.flixtracking &&
      window.flixtracking.onLogFromApp(\`${escaped}\`);
    } catch(e){}
    true;
  `;

  flixWebviewRefGlobal.injectJavaScript(js);
}

/* ============================================================================
 * Hook: useFlixViewportTracking
 * ========================================================================== */

function useFlixViewportTracking({ containerRef, webviewRef }) {
  const lastSentRef = useRef(0);
  const THROTTLE_MS = 50;

  const sendViewportMetrics = () => {
    if (!containerRef.current || !webviewRef.current) return;

    const now = Date.now();
    if (now - lastSentRef.current < THROTTLE_MS) return;
    lastSentRef.current = now;

    containerRef.current.measureInWindow((x, y, width, height) => {
      const viewportHeight = Dimensions.get('window').height;

      const webTop = y;
      const webBottom = y + height;

      const intersectionTop = Math.max(webTop, 0);
      const intersectionBottom = Math.min(webBottom, viewportHeight);

      if (intersectionBottom <= intersectionTop) return;

      const topOffset = intersectionTop - webTop;
      const visibleHeight = intersectionBottom - intersectionTop;

      const js = `
        (function(){
          try {
            if (window.flixtracking &&
                typeof window.flixtracking.onScrollFromApp === 'function') {
              window.flixtracking.onScrollFromApp(
                ${topOffset.toFixed(2)},
                ${visibleHeight.toFixed(2)}
              );
            }
          } catch(e){}
        })();
        true;
      `;

      webviewRef.current.injectJavaScript(js);
    });
  };

  return { sendViewportMetrics };
}

/* ============================================================================
 * Component: InpageHtmlView
 * ========================================================================== */

export const InpageHtmlView = forwardRef(({
  productParams = {},
  baseUrl = 'https://example.com',
  style,
  showLoader = false,
  parentScrollRef,
  onError,
  onLoadedHtml,
}, ref) => {
  const [html, setHtml] = useState(null);
  const [loading, setLoading] = useState(true);
  const [webviewHeight, setWebviewHeight] = useState(50);

  const webviewRef = useRef(null);
  const containerRef = useRef(null);
  const lastHeightRef = useRef(0);

  const { sendViewportMetrics } = useFlixViewportTracking({
    containerRef,
    webviewRef,
  });

  /* expose to parent */
  useImperativeHandle(ref, () => ({
    onParentScroll: sendViewportMetrics,
  }));

  /* load html */
  useEffect(() => {
    let mounted = true;

    (async () => {
      try {
        const htmlResponse = await getInpageHtml(productParams);
        if (!mounted) return;

        if (!htmlResponse) {
          onError?.('No HTML from SDK');
          return;
        }

        setHtml(String(htmlResponse));
        onLoadedHtml?.(String(htmlResponse));
      } catch (e) {
        onError?.(String(e));
      } finally {
        mounted && setLoading(false);
      }
    })();

    return () => { mounted = false; };
  }, [JSON.stringify(productParams)]);

  /* re-send on resize */
  useEffect(() => {
    if (webviewHeight > 1) {
      requestAnimationFrame(sendViewportMetrics);
    }
  }, [webviewHeight]);

  function confirmAndOpenExternalLink(url) {
    Alert.alert(
      'Leave the app?',
      'You are about to open an external link in your browser.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Open',
          style: 'destructive',
          onPress: () => Linking.openURL(url).catch(() => {}),
        },
      ]
    );
  }

  function handleScrollToViewport(viewportTop, animated = true) {
  if (!containerRef.current || !parentScrollRef?.current) return;

  containerRef.current.measureInWindow((x, y) => {
      const mediaTop = 0; // RN handles status bar internally
      const appBarHeight = 0; // jeśli masz custom header → wstrzyknij

      const scrollOffset =
        parentScrollRef.current.__lastScrollY +
        y +
        viewportTop -
        mediaTop -
        appBarHeight;

      try {
        parentScrollRef.current.scrollTo({
          y: scrollOffset,
          animated,
        });
      } catch (e) {}
    });
  }

  const injectedJS = `
(function () {
  /* ============================
   * HEIGHT / RESIZE OBSERVER
   * ============================ */

  var lastHeight = -1; // ensures first send always happens

  function sendHeight() {
    try {
      var h =
        document.body.scrollHeight ||
        document.documentElement.scrollHeight ||
        1;

      h = Math.ceil(h);

      if (lastHeight !== -1 && Math.abs(h - lastHeight) < 2) {
        return;
      }

      lastHeight = h;

      window.ReactNativeWebView.postMessage(
        JSON.stringify({
          type: 'height',
          height: h,
        })
      );
    } catch (e) {}
  }

  try {
    var mo = new MutationObserver(function () {
      sendHeight();
    });

    mo.observe(document.body, {
      childList: true,
      subtree: true,
      attributes: true,
    });
  } catch (e) {}

  window.addEventListener('load', function () {
    sendHeight();
  });

  // initial send
  sendHeight();

  /* ============================
   * LINK INTERCEPTOR (iOS SAFE)
   * ============================ */
  document.addEventListener(
    'click',
    function (event) {
      try {
        var el = event.target;

        while (el && el.tagName !== 'A') {
          el = el.parentElement;
        }

        if (!el) return;

        var href = el.getAttribute('href');
        if (!href) return;

        if (
          href === '#' ||
          href.startsWith('javascript:') ||
          href.startsWith('data:')
        ) {
          return;
        }

        if (href.startsWith('/') || href.startsWith('#')) {
          return;
        }

        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation();

        window.ReactNativeWebView.postMessage(
          JSON.stringify({
            type: 'external-link',
            url: el.href,
          })
        );
      } catch (e) {}
    },
    true
  );

  /* ============================
   * BLOCK window.open / target=_blank
   * ============================ */
  try {
    window.open = function (url) {
      if (url) {
        window.ReactNativeWebView.postMessage(
          JSON.stringify({
            type: 'external-link',
            url: url,
          })
        );
      }
      return null;
    };
  } catch (e) {}

  /* ============================
 * SCROLL TO VIEWPORT (JS → APP)
 * ============================ */
  if (!window.flixtracking) {
    window.flixtracking = {};
  }

  window.flixtracking.scrollToViewport = function (viewportTop, animated) {
    try {
      window.ReactNativeWebView.postMessage(
        JSON.stringify({
          type: 'scroll-to-viewport',
          viewportTop: Number(viewportTop) || 0,
          animated: animated !== false,
        })
      );
    } catch (e) {}
  };
})();
true;
`;

  function onMessage(event) {
    try {
      const data = JSON.parse(event.nativeEvent.data);

      if (data.type === 'height') {
        const h = Math.max(1, data.height);
        if (h !== lastHeightRef.current) {
          lastHeightRef.current = h;
          setWebviewHeight(h);
        }
      }

      if (data.type === 'external-link') {
        confirmAndOpenExternalLink(data.url);
      }

      if (data.type === 'scroll-to-viewport') {
        handleScrollToViewport(data.viewportTop, data.animated);
        return;
      }
    } catch (_) {}
  }

  return (
    <View
      ref={containerRef}
      style={[
        { width: '100%', height: webviewHeight, overflow: 'hidden' },
        style,
      ]}
    >
      {loading && showLoader && (
        <View style={styles.loaderOverlay}>
          <ActivityIndicator size="small" />
        </View>
      )}

      <WebView
        ref={r => {
          webviewRef.current = r;
          setWebViewRef(r);
        }}
        source={html
          ? { html, baseUrl }
          : { html: '<html><body></body></html>' }
        }
        injectedJavaScript={injectedJS}
        onMessage={onMessage}
        onLoadEnd={() => requestAnimationFrame(sendViewportMetrics)}
        onShouldStartLoadWithRequest={request => {
          if (request.navigationType === 'click') {
            confirmAndOpenExternalLink(request.url);
            return false;
          }
          return true;
        }}
        scrollEnabled={false}
        javaScriptEnabled
        domStorageEnabled
        webviewDebuggingEnabled
        allowsInlineMediaPlayback={true}
        mediaPlaybackRequiresUserAction={false} 
        style={{ backgroundColor: 'transparent' }}
      />
    </View>
  );
});

/* ============================================================================
 * Styles
 * ========================================================================== */

const styles = StyleSheet.create({
  loaderOverlay: {
    ...StyleSheet.absoluteFillObject,
    zIndex: 2,
    justifyContent: 'center',
    alignItems: 'center',
  },
});
