# react-native-flix-inpage

A React Native bridge for the **FlixMedia SDK**, allowing you to load FlixMedia product HTML inside your React Native application.

## ✨ Features
- Native bridge to the FlixMedia Inpage SDK  
- Renders dynamic product HTML via `InpageHtmlView`  
- Simple initialization using username & password  
- Works with React Native 0.73+ and Expo (prebuild)

---

## 📦 Installation

```bash
npm install "path-to-SDK-package"
```

## Getting Started

Import the Flixmedia React Native package:
```
import { InpageHtmlView, initialize } from 'react-native-flix-inpage';
```

Then insert your username and password inside initialize method like:
```
await initialize('username', 'password');
```

Add InpageHtmlView inside the ScrollView and insert your product data inside it:
```
<ScrollView>
...
<InpageHtmlView
   productParams={{
      mpn: "",
      ean: "",
      distributorId: 0,
      isoCode: "",
      flIsoCode: "",
      brand: "",
      title: "",
      price: "",
      currency: "",
   }}
   baseUrl="https://www.example.com"
   style={{ backgroundColor: 'white' }}
   onError={(err) => console.warn('Inpage error:', err)}
   onLoadedHtml={(html) => console.log('Inpage loaded, length:', html.length)}
/>
...
</ScrollView>
```

## License
© FlixMedia. All rights reserved.